/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 grass grass.png 
 * Time-stamp: Thursday 04/08/2021, 06:01:17
 * 
 * Image Information
 * -----------------
 * grass.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GRASS_H
#define GRASS_H

extern const unsigned short grass[38400];
#define GRASS_SIZE 76800
#define GRASS_LENGTH 38400
#define GRASS_WIDTH 240
#define GRASS_HEIGHT 160

#endif

